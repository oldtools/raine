About the sound in SDL :

Some sound drivers are broken in windows and forbid the use of very small
buffers for sound updates. It's not a soundcard problem because the same
sound card works flawlessly in linux with a small buffer.
The consequence is that the length of the buffer creates a delay between
what is on screen and the sound. This delay is noticeable at 22 Khz, and
huge at 11Khz (but who uses 11Khz anyway ?). So you have 2 options :

1) To find out if you have such a broken sound driver, edit raine32.cfg
and change this setting in the sound section :
smallest_sound_buffer = 1
Then restart raine and play something with sound. If your sound is
perfect then you have a good driver, otherwise, too bad !!!

2) If your driver is bad and you want to minimize this delay, play in
44 Khz. In 44 Khz the buffer will still have the same size and will be
played faster.

The default is to use a safe buffer since lots of drivers seem to have
this bug. So the default is now to also use 44 Khz in windows.

